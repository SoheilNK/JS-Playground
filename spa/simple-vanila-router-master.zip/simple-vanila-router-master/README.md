# Simple Vanilla Router

This is the illustration of SPA(Single Page Routing) using Vanilla JavaScript.
Check out the article on medium from [here](https://medium.com/@am_pra_veen/implementing-simple-spa-routing-using-vanilla-javascript-53abe399bf3c).

## Get Started With Project
* Install live-server by running `npm i -g live-server`.
* Run `live-server` for starting the project.