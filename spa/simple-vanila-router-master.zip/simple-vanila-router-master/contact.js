let contact = `
  <h1>I am contact Page</h1>
`